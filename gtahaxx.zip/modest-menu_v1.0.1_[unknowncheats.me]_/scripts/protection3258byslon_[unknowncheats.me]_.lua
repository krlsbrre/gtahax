
local pro = menu.add_submenu("====== Protections ======")
local boolall = false 
local blockSocialClubSpamState = false
 
local function Text(text)
	pro:add_action(text, function() end)
end
 
Text("➫GTAv1.69 Protections")
Text("--")
 
local function Activity(bool)
	globals.set_bool(1683951+587, bool) --1450115979
end
 
local function Bounty(bool)
	globals.set_bool(1683951+65, bool) --1517551547
end
 
local function CeoKick(bool)
	globals.set_bool(1683951+559, bool) --618715507
end
 
local function KickCrashes(bool)
	globals.set_bool(1683951+775, bool) -- -901348601
	globals.set_bool(1683951+456, bool) -- 323285304
	globals.set_bool(1683951+611, bool) -- 247853458
	globals.set_bool(1683951+626, bool) -- -1638522928
	globals.set_bool(1683951+526, bool) -- -1604421397
	globals.set_bool(1683951+603, bool) -- -797526379
	globals.set_bool(1683951+870, bool) -- 2021051510
end
 
local function getKickCrashesState()
	return ( globals.get_bool(1683951+775) and
	globals.get_bool(1683951+456) and 
	globals.get_bool(1683951+611) and
	globals.get_bool(1683951+626) and
	globals.get_bool(1683951+526) and
	globals.get_bool(1683951+603) and
	globals.get_bool(1683951+870))
end
 
local function CeoBan(bool)
	globals.set_bool(1683951+581, bool) --1531565154
end
 
local function SoundSpam(bool)
	globals.set_bool(1683951+454, bool) -- -1773335296
	globals.set_bool(1683951+872, bool) -- 606464409
	globals.set_bool(1683951, bool)
	--globals.set_bool(1670529, bool)
	globals.set_bool(1683951+633, bool) -- 288412940
	globals.set_bool(1683951+17, bool) -- -1595661064
end
 
local function getSoundSpamState()
	return (globals.get_bool(1683951+454) and
	globals.get_bool(1683951+872) and
	globals.get_bool(1683951) and
	--globals.get_bool(1670529) and
	globals.get_bool(1683951+633) and
	globals.get_bool(1683951+17))
end
 
local function InfiniteLoad(bool)	
	globals.set_bool(1683951+582, bool)  -- -808991722
	globals.set_bool(1683951+651, bool) -- 1103127469
end
 
local function getInfiniteLoadState()
	return (globals.get_bool(1683951+582) and
	globals.get_bool(1683951+651))
end
 
local function Collectibles(bool)
	globals.set_bool(1683951+837, bool)  -- 968269233
end
 
local function PassiveMode(bool)
	globals.set_bool(1683951+571, bool) --949664396
end
 
local function TransactionError(bool) 
	globals.set_bool(1683951+372, bool) -- -830063381
end
 
local function RemoveMoneyMessage(bool) 
	globals.set_bool(1683951+455, bool) -- 1655503526
	globals.set_bool(1683951+22, bool) -- 996099702
	globals.set_bool(1683951+632, bool) -- -1986344798
end
 
local function getRemoveMoneyMessageState()
	return (globals.get_bool(1683951+455) and
	globals.get_bool(1683951+22) and
	globals.get_bool(1683951+632))
end
 
local function ExtraTeleport(bool) 
	globals.set_bool(1683951+328, bool)  -- 1541018842
	globals.set_bool(1683951+767, bool)  -- 259469385
    globals.set_bool(1683951+866, bool) -- 1669592503
    globals.set_bool(1683951+867, bool) -- -375628860
    globals.set_bool(1683951+862, bool) -- 373376135
end
 
local function getExtraTeleportState()
	return (globals.get_bool(1683951+328) and
	globals.get_bool(1683951+767) and globals.get_bool(1683951+866) and globals.get_bool(1683951+867) and globals.get_bool(1683951+862))
end
 
local function ClearWanted(bool) 
	globals.set_bool(1683951+513, bool) -- -1704545346
end
 
local function OffTheRadar(bool) 
	globals.set_bool(1683951+515, bool) -- 57493695
end
 
local function SendCutscene(bool) 
	globals.set_bool(1683951+827, bool) -- -1951335381
end
 
local function Godmode(bool) 
	globals.set_bool(1683951+2, bool) -- 800157557
end
 
local function PersonalVehicleDestroy(bool) 
	globals.set_bool(1683951+73, bool) -- 109434679
	globals.set_bool(1683951+638, bool) -- -1353750176
end
 
local function getPersonalVehicleDestroyState()
	return (globals.get_bool(1683951+73) and
	globals.get_bool(1683951+638))
end
 
local function RemoteGlobalModification(bool)
	local setting = 0
	if bool then
		setting = 1
	end
	globals.set_int(1683951+815, setting) -- -527835094
	globals.set_int(1683951+473, setting) -- 1169323649
end
 
local function getRemoteGlobalModificationState()
	return ((globals.get_int(1683951+815) == 1) and
	(globals.get_int(1683951+473) == 1))
end
 
local function BlockSocialclubSpam(bool)
	blockSocialClubSpamState = bool
end
 
local function getBlockSocialClubSpamState()
	return blockSocialClubSpamState
end
 
 
 
local function All(bool) 
	Activity(bool)
	Bounty(bool)
	CeoKick(bool)
	CeoBan(bool)
	SoundSpam(bool)
	InfiniteLoad(bool)
	PassiveMode(bool)
	TransactionError(bool)
	RemoveMoneyMessage(bool)
	ClearWanted(bool)
	OffTheRadar(bool)
	PersonalVehicleDestroy(bool)
	SendCutscene(bool)
	Godmode(bool)
	Collectibles(bool)
	ExtraTeleport(bool)
	KickCrashes(bool)
	RemoteGlobalModification(bool)
	BlockSocialclubSpam(bool)
end
 
pro:add_toggle("Activate All", function()
	return boolall
end, function()
	boolall = not boolall
	All(boolall)
end)
Text("--")
pro:add_toggle("Block Start Activity", function() --Credits to YimMenu
	return globals.get_bool(1683951+587)
end, function()
	Activity(not globals.get_bool(1683951+587))
end)
 
pro:add_toggle("Block Bounty", function()
	return globals.get_bool(1683951+65)
end, function()
	Bounty(not globals.get_bool(1683951+65))
end)
 
 
pro:add_toggle("Block Socialclub Spam", function()
	return getBlockSocialClubSpamState()
end, function(value)
	BlockSocialclubSpam(value)
end)
 
pro:add_toggle("Block Remote Global Modification", function()
	return getRemoteGlobalModificationState()
end, function()
	RemoteGlobalModification(not getRemoteGlobalModificationState())
end)
 
pro:add_toggle("Block Some Kicks&&Crashes", function()
	return getKickCrashesState()
end, function()
	KickCrashes(not getKickCrashesState())
end)
 
pro:add_toggle("Block Ceo Kick", function()
	return globals.get_bool(1683951+559)
end, function()
	CeoKick(not globals.get_bool(1683951+559))
end)
 
pro:add_toggle("Block Ceo Ban", function()
	return globals.get_bool(1683951+581) 
end, function()
	CeoBan(not globals.get_bool(1683951+581))
end)
 
pro:add_toggle("Block Sound Spam", function()
	return getSoundSpamState()
end, function()
	SoundSpam(not getSoundSpamState())
end)
 
pro:add_toggle("Block Infinite Loadingscreen", function()
	return getInfiniteLoadState()
end, function()
	InfiniteLoad(not getInfiniteLoadState())
end)
 
pro:add_toggle("Block Passive Mode", function()
	return globals.get_bool(1683951+571) 
end, function()
	PassiveMode(not globals.get_bool(1683951+571))
end)
 
pro:add_toggle("Block Transaction Error", function()
	return globals.get_bool(1683951+372)
end, function()
	TransactionError(not globals.get_bool(1683951+372))
end)
 
pro:add_toggle("Block Modded Notifys/SMS", function()
	return getRemoveMoneyMessageState()
end, function()
	RemoveMoneyMessage(not getRemoveMoneyMessageState())
end)
 
pro:add_toggle("Block Clear Wanted", function()
	return globals.get_bool(1683951+513)
end, function()
	ClearWanted(not globals.get_bool(1683951+513))
end)
 
pro:add_toggle("Block Off The Radar", function()
	return globals.get_bool(1683951+515)
end, function()
	OffTheRadar(not globals.get_bool(1683951+515))
end)
 
pro:add_toggle("Block Personal Vehicle Destroy", function()
	return getPersonalVehicleDestroyState()
end, function()
	PersonalVehicleDestroy(not getPersonalVehicleDestroyState())
end)
 
pro:add_toggle("Block Send to Cutscene", function()
	return globals.get_bool(1683951+827)
end, function()
	SendCutscene(not globals.get_bool(1683951+827))
end)
 
pro:add_toggle("Block Remove Godmode", function()
	return globals.get_bool(1683951+2)
end, function()
	Godmode(not globals.get_bool(1683951+2))
end)
 
pro:add_toggle("Block Give Collectibles", function()
	return globals.get_bool(1683951+837)
end, function()
	Collectibles(not globals.get_bool(1683951+837))
end)
 
pro:add_toggle("Block Cayo && Beach Teleport", function()
	return getExtraTeleportState()
end, function()
	ExtraTeleport(not getExtraTeleportState())
end)
 
 
function OnScriptsLoaded()
	local social_controller = script("social_controller")
	while true do
		if blockSocialClubSpamState then
			if social_controller:is_active() then
				social_controller:set_int(169, 0)
			end
		end
		sleep(1)
	end
end
 
menu.register_callback('OnScriptsLoaded', OnScriptsLoaded)
 
Text("--")
Text("By UC - Community")
Text("Original Code ➫ [CENSORED] ")
Text("Improvements by ➫ [CENSORED]")
Text("Addons by [CENSORED] and [CENSORED]")
Text("--")