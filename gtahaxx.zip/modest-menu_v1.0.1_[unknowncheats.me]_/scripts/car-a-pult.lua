-----------------------------------
--Original Script by Quad_Plex
--V2.1 updated for gta 2944
-----------------------------------
local VehicleSpawnGlobal2 = 2694613
local VehicleSpawnGlobal = 2639889
 
local function createVehicle(modelHash, pos)
	if not localplayer:is_in_vehicle() then
		globals.set_int(VehicleSpawnGlobal + 46, modelHash)
		globals.set_float(VehicleSpawnGlobal + 42, pos.x)
		globals.set_float(VehicleSpawnGlobal + 43, pos.y)
		globals.set_float(VehicleSpawnGlobal + 44, pos.z)
		local vector = localplayer:get_heading()
		local angle = math.deg(math.atan(vector.y, vector.x))
		if angle < 0 then angle = angle + 360 end
		globals.set_float(VehicleSpawnGlobal + 45, angle)
		globals.set_boolean(VehicleSpawnGlobal + 41, true)
	else
		--Workaround, have to use this second spawner if the player is in a car
		globals.set_boolean(VehicleSpawnGlobal2 + 5, false) -- SpawnVehicles
		globals.set_boolean(VehicleSpawnGlobal2 + 2, false) -- SpawnVehicles
		globals.set_float(VehicleSpawnGlobal2 + 7 + 0, pos.x) -- pos.x
		globals.set_float(VehicleSpawnGlobal2 + 7 + 1, pos.y) -- pos.y
		globals.set_float(VehicleSpawnGlobal2 + 7 + 2, pos.z) -- pos.z
		globals.set_int(VehicleSpawnGlobal2 + 27 + 66, modelHash) -- modelHash
		globals.set_boolean(VehicleSpawnGlobal2 + 5, true) -- SpawnVehicles
		globals.set_boolean(VehicleSpawnGlobal2 + 2, true) -- SpawnVehicles
		--thanks to  @Alice2333 on UKC for showing me the second spawner code
	end
end
 
local weapon_data = {}
local enabled = false
local isActive = false
local function spawnCarWhereAiming()
	if not enabled then return end
	isActive = true
	--check weapon hit force and put in table
	local weapon = localplayer:get_current_weapon()
	if weapon ~= nil then
		local force = weapon:get_vehicle_force()
		if force ~= nil and force < 100000 then
			weapon_data[weapon:get_name_hash()] = force
			weapon:set_vehicle_force(99900000)
		end
	end
	local pos = (localplayer:get_position() + localplayer:get_heading()*2.2)
	if localplayer:is_in_vehicle() then
		pos = (localplayer:get_position() + localplayer:get_heading()*11)
	end
	createVehicle(joaat("Youga4"), pos + vector3(0,0,1))
	sleep(0.2)
	isActive = false
end
 
local hotkey
local function carAPult()
	if not localplayer or localplayer == nil then return end
	
	enabled = not enabled
	if enabled then
		--register hotkey to left click for continually spawning cars
		hotkey = menu.register_hotkey(1, function() if not isActive then spawnCarWhereAiming() end end)
	else
		--reset weapon hit force from table
		local weapon = localplayer:get_current_weapon()
		if weapon ~= nil and weapon:get_vehicle_force() == 99900000 then
			local force = weapon_data[weapon:get_name_hash()]
			if force ~= nil then
				weapon:set_vehicle_force(force)
			end
		end
		
		--unregister hotkey
		menu.remove_hotkey(hotkey)
	end
end
 
--menu.add_toggle("Enable Car-A-Pult", function() return enabled end, carAPult)
 
--multiply key on numpad
menu.register_hotkey(106, carAPult)